package com.usmaan.tictactoe

data class Position(val row: Int, val column: Int)