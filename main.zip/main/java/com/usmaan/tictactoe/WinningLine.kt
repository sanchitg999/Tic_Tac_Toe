package com.usmaan.tictactoe

enum class WinningLine {
    ROW_0,
    ROW_1,
    ROW_2,
    COLUMN_0,
    COLUMN_1,
    COLUMN_2,
    DIAGONAL_LEFT,
    DIAGONAL_RIGHT,
}